var api = require('./api');
api.get('Tester', function(data){
    console.log(data);
});